const api = {
  // https协议
  protocol: 'https',
  // http协议
  // protocol: 'http',

  // 请求域名
  // host: '119.23.27.158:8090/', // 测试环境
  // host: '192.168.9.245:8088/',
  host: 'cs1.gzqqs.com/',  // 正式环境

  // 基础路径
  basePath: 'qqs/H5/OrderSystem/'
}

export default api
