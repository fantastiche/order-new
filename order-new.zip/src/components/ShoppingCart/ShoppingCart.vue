<template>
</template>

<script>
  export default {
    data: function () {
      return {}
    },
    methods: {},
    created: function () {
    }
  }
</script>

<style lang="less" type="text/less" scoped>
</style>
