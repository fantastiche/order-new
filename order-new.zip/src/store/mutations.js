import * as types from './mutation-types'

const mutations = {
}

export default mutations
